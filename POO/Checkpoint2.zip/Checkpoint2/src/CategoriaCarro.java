public class CategoriaCarro {
    private String nome;
    private double tarifaDiaria;

    public CategoriaCarro(String nome, double tarifaDiaria) {
        this.nome = nome;
        this.tarifaDiaria = tarifaDiaria;
    }

    // Getters e setters
}
